<?php
/*
Plugin Name: Sample Plugin
Description: This is Sample PLugin. Copy header into new file to create a new plugin
Author: Merv Barrett
Version: 1.0.0
*/