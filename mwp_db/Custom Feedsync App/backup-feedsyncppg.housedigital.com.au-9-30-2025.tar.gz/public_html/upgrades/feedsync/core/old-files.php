<?php

global $_old_files;

/** @var List of files to be deleted */
$_old_files = array(

	// 3.2 test

);